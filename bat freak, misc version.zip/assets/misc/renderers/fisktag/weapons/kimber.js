loadTextures({
    "base":       "misc:kimber",
    "crosshair":  "misc:crosshairs/pistol"
});

var utils = implement("fisktag:external/utils");

var model;

var cancelAnimations = false;

function init(renderer) {
    model = utils.createModel(renderer, "misc:kimber", "base");
    model.bindAnimation("misc:john/kimber_reload").setData((entity, data) => {
        if (cancelAnimations) {
            data.load(0);
            return;
        }
        data.load(0, entity.getInterpolatedData("fiskheroes:weapon_animation_timer"));
    });
    renderer.setModel(model);	

    utils.addPlayerAnimation(renderer, "misc:john/reload")
    .setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:reload_timer"));
    });
    
    utils.makeDilatingCrosshair(renderer, "crosshair", 22, 18, [
        { "pos": [9, 7], "size": [5, 5] }, // Center
        { "pos": [1, 7], "size": [8, 5], "axis": [-1, 0] }, // Left
        { "pos": [14, 7], "size": [8, 5], "axis": [1, 0] }, // Right
        { "pos": [9, 1], "size": [5, 6], "axis": [0, -1] }, // Top
        { "pos": [9, 12], "size": [5, 6], "axis": [0, 1] } // Bottom
    ], 6, 4);
    
    utils.bindScopedBeam(renderer, "misc:bullet", 0xFFA03A, [
        { "firstPerson": [-6.0, 3.0, -18.0], "offset": [-0.5, 16.0, -3.5], "size": [1.0, 1.0] }
    ], [6.0, -2.0, -2.0]);
}

function render(renderer, entity, glProxy, renderType, scopeTimer, recoil, isLeftSide) {
    cancelAnimations = false;
    
    if (renderType === "EQUIPPED" || renderType === "EQUIPPED_FIRST_PERSON") {
        cancelAnimations = false;
        if (renderType === "EQUIPPED_FIRST_PERSON") {
            var reload = Math.sin(Math.PI*entity.getInterpolatedData("fiskheroes:reload_timer"))
            glProxy.translate(0.05, -0.05+1*reload, 0);
            
            var f = 1 - scopeTimer * 0.4;
            recoil *= 0.3;
            glProxy.rotate(-recoil * (20 - scopeTimer * 7), 1, 0, 0);
            glProxy.translate(-0.05*scopeTimer, -0.65*scopeTimer * -0.125, scopeTimer * 0.2);
            glProxy.translate(0.02 * recoil * (1 - scopeTimer), -0.04 * recoil * f, (Math.sin(recoil * Math.PI) * 0.1) * f);
        }
    }
    else if (renderType === "EQUIPPED_IN_SUIT") {
        cancelAnimations = true;
    }
    else if (renderType === "ENTITY" || renderType === "INVENTORY") {
        cancelAnimations = true;
    }
    
    glProxy.scale(1.2);
    
    
}